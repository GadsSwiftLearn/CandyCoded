package com.pluralsight.candycoded;

@interface NonNull {
}
